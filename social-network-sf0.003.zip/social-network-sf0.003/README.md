Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/b64516edf07e918ef2f4e5c7182aeb16348d39ce>
