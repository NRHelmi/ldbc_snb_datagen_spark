Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/54f5cc7c81eb73ff4efda87129450734e33cd767>
