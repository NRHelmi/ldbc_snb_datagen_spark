Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/b58a63f8cc1d8b02b0930883078dc33ce04311c0>
