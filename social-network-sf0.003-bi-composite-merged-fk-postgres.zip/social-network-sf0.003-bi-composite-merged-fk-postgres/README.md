Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/8570f78486ab3cf4cb0b539e0a5e0569ec6dfc4c>
