Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/255f776f44c73432f4be1df4c07761c61bbd518f>
