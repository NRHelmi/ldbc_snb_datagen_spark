Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/21b407029454ac506461ee34fabec3ac70f08b4e>
