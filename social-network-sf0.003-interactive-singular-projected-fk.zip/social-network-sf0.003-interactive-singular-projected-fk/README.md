Generated with <https://github.com/ldbc/ldbc_snb_datagen_spark/commit/8f3f3ea4ea9b639aa696905fa2d0b04570d1c0ce>
